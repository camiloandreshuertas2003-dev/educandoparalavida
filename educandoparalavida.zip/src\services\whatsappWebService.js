const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcodeTerminal = require('qrcode-terminal');
const QRCode = require('qrcode');
const path = require('path');

let client = null;
let currentQrCode = null;
let currentQrDataUri = null;
let clientStatus = 'disconnected'; // 'disconnected', 'qr_ready', 'authenticated', 'ready'
let userProfile = null;

function initWhatsAppWeb() {
  if (client) {
    return client;
  }

  console.log('⚡ Inicializando cliente WhatsApp Web (QR Mode)...');
  clientStatus = 'initializing';

  client = new Client({
    authStrategy: new LocalAuth({
      clientId: 'colegio-bot-session',
      dataPath: path.join(__dirname, '../../.wwebjs_auth')
    }),
    puppeteer: {
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-gpu'
      ]
    }
  });

  client.on('qr', async (qr) => {
    console.log('===================================================');
    console.log('📱 ¡NUEVO CÓDIGO QR GENERADO DE WHATSAPP WEB!');
    console.log('Escanea este código QR con WhatsApp en tu celular:');
    console.log('===================================================');
    
    currentQrCode = qr;
    clientStatus = 'qr_ready';

    // Imprimir QR en consola
    qrcodeTerminal.generate(qr, { small: true });

    // Convertir QR a Imagen Data URI para la web
    try {
      currentQrDataUri = await QRCode.toDataURL(qr);
    } catch (err) {
      console.error('Error generando Data URI del QR:', err.message);
    }
  });

  client.on('authenticated', () => {
    console.log('✅ WhatsApp Web Autenticado con éxito');
    clientStatus = 'authenticated';
    currentQrCode = null;
    currentQrDataUri = null;
  });

  client.on('auth_failure', (msg) => {
    console.error('❌ Error de Autenticación WhatsApp Web:', msg);
    clientStatus = 'disconnected';
  });

  client.on('ready', async () => {
    console.log('🎉 ¡WHATSAPP WEB CLIENTE LISTO Y CONECTADO 100%!');
    clientStatus = 'ready';
    currentQrCode = null;
    currentQrDataUri = null;

    try {
      const info = client.info;
      userProfile = {
        name: info.pushname || 'Colegio Educando para la Vida',
        phone: info.wid ? info.wid.user : ''
      };
      console.log(`📱 Sesión iniciada como: ${userProfile.name} (+${userProfile.phone})`);
    } catch (e) {}
  });

  client.on('disconnected', (reason) => {
    console.warn('⚠️ WhatsApp Web desconectado:', reason);
    clientStatus = 'disconnected';
    currentQrCode = null;
    currentQrDataUri = null;
  });

  // Manejar mensajes entrantes
  client.on('message', async (msg) => {
    if (msg.fromMe || !msg.from || !msg.from.endsWith('@c.us')) {
      return;
    }

    const from = msg.from.replace('@c.us', '').replace(/[^\d]/g, '');
    const texto = msg.body ? msg.body.trim() : '';

    console.log(`📩 [WhatsApp Web] Mensaje de ${from}: "${texto}"`);

    // Evitar requerir circularmente al inicio
    const { procesarMensaje } = require('./conversationService');
    try {
      await procesarMensaje(from, texto);
    } catch (err) {
      console.error(`❌ Error procesando mensaje de ${from}:`, err.message);
    }
  });

  client.initialize().catch((err) => {
    console.error('❌ Error inicializando Puppeteer para WhatsApp Web:', err.message);
    clientStatus = 'disconnected';
  });

  return client;
}

function getWWebStatus() {
  return {
    status: clientStatus,
    hasQr: !!currentQrDataUri,
    qrDataUri: currentQrDataUri,
    userProfile
  };
}

function isWhatsAppWebReady() {
  return clientStatus === 'ready' && client !== null;
}

async function enviarMensajeWWeb(to, texto) {
  if (!isWhatsAppWebReady()) {
    throw new Error('WhatsApp Web no está conectado');
  }

  let formattedTo = to.replace(/[^\d]/g, '');
  if (!formattedTo.endsWith('@c.us')) {
    formattedTo = `${formattedTo}@c.us`;
  }

  const res = await client.sendMessage(formattedTo, texto);
  console.log(`📤 [WhatsApp Web] Mensaje enviado a ${to}`);
  return res;
}

module.exports = {
  initWhatsAppWeb,
  getWWebStatus,
  isWhatsAppWebReady,
  enviarMensajeWWeb
};
